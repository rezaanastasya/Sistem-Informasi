<?php

namespace App\Filament\Resources;

use App\Filament\Resources\AkunResource\Pages;
use App\Models\Akun;
use Filament\Forms;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;

class AkunResource extends Resource
{
    protected static ?string $model = Akun::class;

    protected static ?string $navigationIcon = 'heroicon-o-rectangle-stack';

    public static function form(Form $form): Form
    {
        return $form
            ->schema([
                Forms\Components\TextInput::make('kode_akun')->required(),
                Forms\Components\TextInput::make('nama_akun')->required(),
                Forms\Components\Select::make('jenis_akun')
                    ->options(['Asset'=>'Asset','Liabilitas'=>'Liabilitas','Ekuitas'=>'Ekuitas','Pendapatan'=>'Pendapatan','Beban'=>'Beban'])->required(),
                Forms\Components\Select::make('saldo_normal')
                    ->options(['Debit'=>'Debit', 'Kredit'=>'Kredit'])->required(),
            ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                Tables\Columns\TextColumn::make('kode_akun')->sortable()->searchable(),
                Tables\Columns\TextColumn::make('nama_akun')->searchable(),
                Tables\Columns\TextColumn::make('jenis_akun'),
                Tables\Columns\TextColumn::make('saldo_normal'),
            ])
            ->filters([
                //
            ])
            ->actions([
                Tables\Actions\EditAction::make(),
            ])
            ->bulkActions([
                Tables\Actions\BulkActionGroup::make([
                    Tables\Actions\DeleteBulkAction::make(),
                ]),
            ]);
    }

    public static function getRelations(): array
    {
        return [
            //
        ];
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListAkuns::route('/'),
            'create' => Pages\CreateAkun::route('/create'),
            'edit' => Pages\EditAkun::route('/{record}/edit'),
        ];
    }
}