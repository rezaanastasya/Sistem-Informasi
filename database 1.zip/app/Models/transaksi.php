<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class Transaksi extends Model
{
    protected $guarded = [];

    public function akun() {
        return $this->belongsTo(Akun::class);
    }
}